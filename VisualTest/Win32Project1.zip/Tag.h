#pragma once
#include <iostream>
#include <stdio.h>
#include <string>
#include <stdlib.h>
#include <time.h>
#define Columns 14
#define HeaderSize 14
using namespace std;
class Tag
{
private:
	
public:
	string Name;
	string Description;
	string Units;
	string Path;
	struct Values 
	{
		string Date;		
		string Val;
	} Value;
	string getName() { return Name; };
	string getDescription() { return Description; };
	string getUnits() { return Units; };
	int putName(string _Name);
	int putDescription(string _Description);
	int putUnits(string _Units);
	int ReadHeader(FILE *fp, short TagNumber);
	string ReadValueByDateTime(string Data);
	Tag();
	virtual ~Tag();
};

